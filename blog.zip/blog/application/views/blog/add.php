<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>halaman add</title>
</head>
<body>
    <h2>tamabah data blog</h2>
    <from action="">
        <input type="text">
        <button>tambah</button>
    </from>
</body>
</html>